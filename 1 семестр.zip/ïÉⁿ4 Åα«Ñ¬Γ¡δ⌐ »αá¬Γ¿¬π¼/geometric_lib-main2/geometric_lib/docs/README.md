<<<<<<< HEAD
=======
# User agreement 

Please check out License Agreement for personal usage terms and limitations

---

>>>>>>> release
# Math formulas
## Area
- Circle: S = πR²
- Rectangle: S = ab
- Square: S = a²
<<<<<<< HEAD
- Triangle: S = (a + b + c) / 2
=======
>>>>>>> release

## Perimeter
- Circle: P = 2πR
- Rectangle: P = 2a + 2b
- Square: P = 4a
<<<<<<< HEAD
- Triangle: P = a + b + c
=======

>>>>>>> release
